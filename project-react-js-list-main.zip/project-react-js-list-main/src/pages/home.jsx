function Home(){
    return <div  className="mb-4 text-xl font-semibold">Hello World</div>
}
export default Home;