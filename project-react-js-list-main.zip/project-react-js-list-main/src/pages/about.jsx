function About(){
    return <div  className="mb-4 text-xl font-semibold">Hello dari About</div>
}
export default About;